<?php

//Register component functions (only remove if the function is not longer delcared)

require_once(dirname(__FILE__) . '/component_theme_overwrites.php');
require_once(dirname(__FILE__) . '/component_aspect_size.php');
require_once(dirname(__FILE__) . '/component_background_media.php');
require_once(dirname(__FILE__) . '/component_media.php');
require_once(dirname(__FILE__) . '/component_buttons.php');