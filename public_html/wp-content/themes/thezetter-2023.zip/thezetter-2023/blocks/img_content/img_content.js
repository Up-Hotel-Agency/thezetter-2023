// set the global variables here for JSLint
/*global AOS, jQuery */
"use strict";