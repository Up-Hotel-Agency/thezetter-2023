<?php

require_once('offers.php');
require_once('careers.php');
// require_once('events.php');
// require_once('gallery.php');
require_once('rooms.php');
require_once('team.php');