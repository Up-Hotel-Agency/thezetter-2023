<?php //Template for modal used durring ajax requests ?>

<div class="single-modal js-single-modal-ajax">
	<a href="#" class="modal-close js-modal-close-ajax flex justify-center items-center">
		<svg width="28" height="28" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4.755 19.245L19.245 4.755"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19.245 19.245L4.755 4.755"/></svg>
	</a>
	<div class="single-modal-inner">

	</div>
</div>