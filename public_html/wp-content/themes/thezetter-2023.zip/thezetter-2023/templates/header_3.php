<header class="header flex justify-between items-center theme--default">
	<div class="header-left flex items-center">
		<a title="<?php echo get_bloginfo( 'name' ); ?>" class="logo flex justify-center items-center" href="<?php echo get_bloginfo( 'url' ); ?>">
			<!--Change on server!!  -->
			<?php 
			if(!get_field('not_zetter', 'options')): 
				switch_to_blog(1);
					echo file_get_contents( get_field('header_logo', 'options') ); 
				restore_current_blog();
			else: 
				echo file_get_contents( get_field('header_logo', 'options') ); 
			endif; 
			?>
			<?php if(!get_field('not_zetter', 'options') && !get_field('is_group', 'options')): ?>
				<div class="location-logo">
					<div class="divider-line"></div>
					<p class="location-logo-text"><?php the_field('location_name', 'options'); ?></div>
				</div>
			<?php endif; ?>
		</a>
	</div>
	<div class="header-right flex items-center">
		<?php if(!get_field('not_zetter', 'options')): ?>
			<?php if(get_field('is_group', 'options')): ?>
				<a href="#" class="open-menu js-open-side-menu">Locations</a>
			<?php else: ?>
				<div href="#" class="open-menu js-locations-dropdown">Locations
					<div class="locations-drop-down">
					<?php $current_site = get_current_blog_id(); ?>
					<?php switch_to_blog(1); $i=0; while ( have_rows('hotel_navigation', 'options') ) : the_row(); ?>
						<?php 
						
							$site_id = get_sub_field('site_id'); 
							$site_url = get_site_url($site_id); 
						?>
						<a class="<?php if($site_id == $current_site): ?> active <?php endif; ?>" href="<?php echo $site_url; ?>">The Zetter <?php echo get_sub_field('title_site');?></a>
					<?php $i++; endwhile; restore_current_blog(); ?>
					</div>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<?php wp_nav_menu( array( 'theme_location' => 'Main Menu' , 'container' => false, 'menu_class' => 'list-reset hide-mobile' ) ); ?>
		<?php 
			if(!get_field('is_group', 'options') && !get_field('not_zetter', 'options')):
			?><a href="#" class="open-menu js-open-side-menu">More</a><?php 
			endif;
		?>
		<?php block_buttons(get_field('header_button_field', 'options'), [
			'class' => 'button no-margin button-header',
			'type'  => 'primary'
		]); ?>
		<a href="#" title="Toggle menu" class="hidden nav-toggle js-nav-toggle sm:flex items-center justify-center"><div class="menu-icon"><span></span><span></span><span></span></div></a>
	</div>
	<div class="overlay overlay-menu">
		<div>
			<div class="mini-menu">
				<?php if(get_field('is_group', 'options')): ?>
					<p class="label xs:mb-0">Locations</p>
					<?php $i=0; while ( have_rows('hotel_navigation', 'options') ) : the_row(); ?>
						<?php 	
							$site_id = get_sub_field('site_id'); 
							$site_url = get_site_url($site_id);  
						?>
						<a data-id="<?php echo $i; ?>" href="<?php echo $site_url; ?>" class="h4 <?php if($link == '#'): ?> no-pointer<?php endif; ?>" ><?php echo get_sub_field('title_site', 'options');?></a>
					<?php $i++; endwhile; ?>
				<?php else: ?>
					<p class="label xs:mb-0"><?php echo get_bloginfo('name'); ?></p>
					<?php wp_nav_menu( array( 'theme_location' => 'Secondary Menu' , 'container' => false, 'menu_class' => 'list-reset side-menu' ) ); ?>
				<?php endif; ?>
			</div>

			<div class="mini-menu">
				<p class="label xs:mb-0">About the Zetter</p>
				<?php if(get_field('is_group', 'options')): ?>
					<?php switch_to_blog(1); ?>
						<?php wp_nav_menu( array( 'theme_location' => 'Side Menu' , 'container' => false, 'menu_class' => 'list-reset side-menu' ) ); ?>
					<?php restore_current_blog(); ?>
				<?php else: ?>
					<?php switch_to_blog(1); ?>
						<?php wp_nav_menu( array( 'theme_location' => 'Side Menu Locations' , 'container' => false, 'menu_class' => 'list-reset side-menu' ) ); ?>
					<?php restore_current_blog(); ?>
				<?php endif; ?>
			</div>
			<?php if(get_field('is_group', 'options')): ?>
				<div class="mini-menu">
					<p class="label xs:mb-0">Our other Hotels</p>
					<?php $i=0; while ( have_rows('other_hotels', 'options') ) : the_row(); ?>
						<?php 
							$site_id = get_sub_field('site_id'); 
							$site_url = get_site_url($site_id);  
						?>
						<a data-id="<?php echo $i; ?>" href="<?php echo $site_url; ?>" class="h4 <?php if($link == '#'): ?> no-pointer<?php endif; ?>" ><?php echo get_sub_field('title_site', 'options');?></a>
					<?php $i++; endwhile; ?>
				</div>
			<?php endif; ?>
		</div>
		<div>
			<div class="overlay-bottom">
				<div class="logo-side-menu">
					<!--Change on server!!  -->
					<?php // echo file_get_contents( get_field('side_menu_logo', 'options') ); ?>
					<svg width="52" height="65" viewBox="0 0 52 65" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M50.649 47.1276C48.9497 45.8088 46.612 45.8892 44.8227 46.9935C42.9593 48.1447 41.7365 50.1543 40.5475 51.9313C39.291 51.5737 38.0412 51.1892 36.7937 50.8137C33.2152 49.734 29.6525 48.6119 26.0741 47.5322C22.8822 46.5688 19.6791 45.6031 16.4244 44.861C16.2333 44.8163 16.04 44.776 15.8489 44.7335C16.3772 44.1412 16.9076 43.5511 17.4269 42.952C18.4676 41.7494 19.5061 40.5468 20.5445 39.3464C22.2843 37.3346 24.0241 35.3228 25.7639 33.311C27.5576 31.2388 29.3491 29.1644 31.1428 27.0923C32.3678 25.675 33.5929 24.2601 34.8179 22.8429C35.0202 22.6082 35.2225 22.3712 35.427 22.1387C36.007 21.4793 36.5599 20.7975 37.1106 20.1135C37.522 20.2007 37.9356 20.2834 38.3514 20.3616C40.7475 20.8109 43.3999 21.2044 45.6274 19.9392C47.0638 19.1233 48.0416 17.5675 47.6819 15.8932C47.3155 14.1921 45.6814 13.365 44.054 13.2779C42.9638 13.2197 41.8714 13.5528 40.9993 14.2033C40.1361 14.8493 39.3899 15.6786 38.6931 16.4945C38.0052 17.3015 37.3466 18.1285 36.6858 18.9556C36.3104 18.8662 35.9373 18.7723 35.5687 18.6762C32.0329 17.7552 28.5848 16.4923 25.1457 15.2762C21.4819 13.9797 17.8247 12.643 14.0934 11.5455C12.6144 11.1096 11.1151 10.705 9.59338 10.4501C7.80415 10.1484 5.95199 10.211 4.50892 11.4449C3.16924 12.5894 2.72418 14.8426 3.90202 16.2687C4.99893 17.5988 7.31639 17.5451 8.7707 16.9192C9.66531 16.5347 10.4251 15.8418 11.1174 15.1734C11.9873 14.3374 12.792 13.4388 13.6191 12.5648C13.6326 12.5514 13.6416 12.5357 13.6529 12.5223C16.7525 13.4142 19.796 14.5073 22.8328 15.5825C26.4404 16.8589 30.0369 18.1867 33.712 19.2641C34.4583 19.4832 35.2068 19.6776 35.9575 19.8565C35.5349 20.3751 35.1101 20.8914 34.6673 21.3944C33.93 22.2326 33.2062 23.0843 32.4757 23.9292C30.8663 25.789 29.2592 27.6488 27.652 29.5087C25.8133 31.6345 23.9724 33.7625 22.1337 35.8905C20.6794 37.5715 19.2251 39.2525 17.773 40.9335C16.7436 42.1249 15.7028 43.3029 14.6576 44.481C12.2413 43.978 9.76196 43.598 7.30964 43.6628C5.46872 43.712 3.61206 44.0495 2.15325 45.2365C0.723665 46.4011 -0.348523 48.281 0.105528 50.1587C0.586551 52.1571 2.78487 53.1138 4.69548 53.0915C6.86908 53.0669 8.78418 51.9336 10.3576 50.5343C12.0412 49.0343 13.545 47.34 15.0375 45.6523C18.081 46.258 21.0705 47.1567 24.0421 48.0374C27.6565 49.1081 31.2552 50.2392 34.8606 51.3412C37.6928 52.2063 40.5295 53.1094 43.4179 53.7755C45.043 54.1488 46.7019 54.4618 48.3517 54.0303C49.8892 53.628 51.2694 52.5885 51.7976 51.0618C52.2943 49.6289 51.847 48.062 50.649 47.1321M10.3127 14.4693C9.63384 15.1198 8.88309 15.8217 7.95475 16.0832C7.17253 16.3045 6.2959 16.3492 5.51592 16.0944C4.70897 15.8306 4.34258 15.1488 4.29987 14.3307C4.20322 12.4664 6.02841 11.3845 7.70975 11.3286C9.16855 11.2795 10.6948 11.7221 12.0974 12.0909C12.2323 12.1267 12.3671 12.1647 12.502 12.2004C11.785 12.9671 11.0747 13.7428 10.3149 14.4693M39.6079 17.0623C40.3137 16.2486 41.0937 15.3187 42.0467 14.7867C42.9414 14.286 43.9978 14.2189 44.9733 14.4983C46.2838 14.8739 47.0346 16.119 46.5445 17.4378C45.8005 19.4429 43.1571 19.8274 41.3072 19.7134C40.1519 19.6419 38.9853 19.4563 37.8344 19.2149C38.4143 18.4884 38.9965 17.7642 39.6079 17.0623ZM9.32365 50.0246C7.7592 51.3703 5.61257 52.4231 3.50191 51.8933C2.62303 51.672 1.73292 51.2272 1.31483 50.3912C0.982159 49.7251 1.01138 48.9494 1.23616 48.2542C1.81384 46.4704 3.49967 45.3103 5.27541 44.9392C7.11184 44.5547 9.06291 44.7 10.9106 44.9347C11.8884 45.0577 12.8594 45.2298 13.8259 45.4153C12.4009 47.0225 10.9533 48.6253 9.32365 50.0268M49.7364 52.1929C48.2821 53.3776 46.3265 53.286 44.5957 52.9372C43.6 52.7361 42.6109 52.4969 41.6287 52.2331C42.7953 50.4672 44.0652 48.3883 46.0748 47.5389C47.5808 46.9041 49.9432 47.1567 50.7187 48.8175C51.2806 50.0201 50.7119 51.3993 49.7386 52.1929" fill="#56593B"/> <path d="M6.30725 19.4005C6.38367 19.139 6.23532 18.8663 5.97233 18.788C5.71159 18.712 5.43511 18.8596 5.35644 19.1189C5.30474 19.2955 5.25304 19.472 5.20135 19.6509C4.09319 23.565 3.53125 27.7205 3.53125 32.0011C3.53125 35.2714 3.86392 38.497 4.51802 41.5885C4.56747 41.821 4.77202 41.9797 5.00129 41.9797C5.03501 41.9797 5.06873 41.9752 5.10469 41.9685C5.37218 41.9126 5.54301 41.6511 5.48681 41.3851C4.8462 38.3607 4.52027 35.2021 4.52027 32.0011C4.52027 27.8099 5.06873 23.746 6.15215 19.9191C6.20161 19.7448 6.25106 19.5726 6.30275 19.4005" fill="#56593B"/> <path d="M39.8529 54.7859C39.6303 54.625 39.3224 54.6742 39.1605 54.8955C35.3371 60.1329 30.383 63.0165 25.2131 63.0165C19.5195 63.0165 14.208 59.6098 10.2609 53.4224C10.1148 53.1921 9.80911 53.1251 9.57759 53.2704C9.34607 53.4157 9.27863 53.7197 9.42474 53.9499C13.5606 60.4324 19.1666 64.0022 25.2131 64.0022C30.7089 64.0022 35.9462 60.9734 39.9607 55.4744C40.1203 55.2554 40.0731 54.9469 39.8506 54.7882" fill="#56593B"/> <path d="M44.6 44.7381C44.645 44.7516 44.6899 44.756 44.7349 44.756C44.9507 44.756 45.1485 44.6152 45.2114 44.3984C46.3286 40.4709 46.895 36.2997 46.895 31.9989C46.895 28.6906 46.5556 25.4293 45.8858 22.3043C45.8296 22.0383 45.5643 21.8706 45.2991 21.9265C45.0316 21.9824 44.8608 22.2439 44.9192 22.5099C45.5756 25.5679 45.9082 28.7599 45.9082 31.9989C45.9082 36.2081 45.3553 40.2898 44.2629 44.1301C44.1887 44.3917 44.3415 44.6644 44.6045 44.7381" fill="#56593B"/> <path d="M10.4253 9.43313C10.6479 9.58961 10.9581 9.53819 11.1154 9.31689C14.9613 3.94314 19.9694 0.983549 25.2157 0.983549C31.2982 0.983549 37.0525 4.98481 40.9996 11.9635C41.0895 12.1245 41.258 12.2139 41.4311 12.2139C41.5143 12.2139 41.5975 12.1938 41.6739 12.1513C41.9122 12.0172 41.9976 11.7176 41.8627 11.4807C37.7313 4.18456 31.6646 0 25.2157 0C19.6412 0 14.3477 3.10712 10.3107 8.74688C10.1534 8.96818 10.2051 9.27666 10.4276 9.43313" fill="#56593B"/> </svg>
				</div>
				<div class="close-overlay-menu">
					<div class="close open-menu">Close</div>
				</div>
			</div>
		</div>
	</div>

	<div class="nav-wrap js-booking-toggle">
		<div class="nav-right">
			<?php echo img_sizes(get_field('booking_mask_image', 'options'), ['default' => 'img_1024', 'page_area' => '50', 'tablet_page_area' => '50', 'mobile_page_area' => '50', 'lazy_load' => false]); ?>
		</div>    
		<div class="nav-left container-left container-right flex items-center">
			
			<div class="close-booking-menu nav-toggle">
				<div class="close">Close</div>
			</div>
			<?php 
				wp_enqueue_script( 'flatpickr-js', get_template_directory_uri() . '/assets/js/flatpickr.min.js' );
				wp_enqueue_script( 'block-acf-booking-mask', get_template_directory_uri() . '/assets/js/booking_mask/booking_mask.min.js' );
				wp_enqueue_style( 'block-acf-booking-mask', get_template_directory_uri() . '/assets/css/booking_mask/booking_mask.css' );
				wp_enqueue_style( 'flatpickr', get_template_directory_uri() . '/assets/css/utilities/flatpickr.css' );
				wp_enqueue_style( 'flatpickr-custom', get_template_directory_uri() . '/assets/css/utilities/flatpickr_custom.css' );    
			?>
			<?php include(get_template_directory() . '/templates/bookingmask-sidebar.php'); ?>        
		</div>

	</div>
</header>